package hf.iOffice.test;
import java.sql.Statement;
import com.jayway.android.robotium.solo.Solo;

import android.app.Activity;
import android.test.ActivityInstrumentationTestCase2;
import hf.iOffice.Data.Data_BaseInformation;
import hf.iOffice.Data.Data_connect;
import hf.iOffice.Page.Page;
import hf.iOffice.Page.Login.Page_LogOn;
import hf.iOffice.Page.Login.Page_Setting;
import hf.iOfficeHD.LoginActivity;
public class TestBase extends ActivityInstrumentationTestCase2<LoginActivity>{
	protected Solo solo;
	public Activity activity;
	public Page page;
	public Page_LogOn page_LogOn;
	public Page_Setting page_Setting;
	public Data_connect dataBase_RandomLogin;
	protected Data_BaseInformation data_login=new Data_BaseInformation();
	Statement st=null;
	public TestBase() {
		super("hf.iOfficeHD", LoginActivity.class);
	}

	@Override
	public void setUp() throws Exception {
		super.setUp();
		this.activity = this.getActivity();
		setActivityInitialTouchMode(false); 
		this.solo = new Solo(getInstrumentation(), getActivity());
	}
	
	@Override
	public void tearDown() throws Exception {
		page=new Page(solo);
		page.click_注销();
		try {
			this.solo.finishOpenedActivities();
		} catch (Throwable e) {
			// todo auto-generated catch block
			e.printStackTrace();
		}
		this.activity.finish();
		super.tearDown();
	}
	 
	public void reSetUp() throws Throwable {
		solo.sleep(3000);
		tearDown();
		solo=new Solo(getInstrumentation(),solo.getCurrentActivity());
		setUp();
		data_login=new Data_BaseInformation();
	}
	
	//对XML的内容取最前面一部分
	public String subStringXML(String XML){
		XML=XML.replaceAll("</a>", " ");	
		XML=XML.replaceAll("</p>", "\n");
		XML=XML.replaceAll("<br><b>", "\n");
		XML=XML.replaceAll("<br>", "\n");
		XML=XML.replaceAll("<b>", "\n");
		while(XML.indexOf("<")!=-1&&XML.indexOf(">")!=-1)
			XML=XML.substring(0,XML.indexOf("<"))+XML.substring(XML.indexOf(">")+1);
		XML=XML.replaceAll("&#160;", "");
		XML=XML.replaceAll("\r", "");
		XML=XML.replaceAll("&nbsp;", " ");
		return XML;
	}

	public void login(String IP) throws Exception{	
		page_LogOn = new Page_LogOn(solo);
		//设置IP登录
		if (!IP.equals("")) {
			page_LogOn.click_高级设置();
			page_Setting = new Page_Setting(solo);
			page_Setting.input_服务地址(data_login.loginIP1);
			page_Setting.click_确定();
		}
	}
}
