package hf.iOffice.test.ShowMessage.Operation;
import hf.iOffice.Data.ShowMessage.Operation.Data_ShowMessage_Discuss;
import hf.iOffice.Page.Desktop.Page_DeskTop;
import hf.iOffice.Page.Login.Page_LogOn;
import hf.iOffice.Page.ShowMessage.Page_ShowMessage_Menu;
import hf.iOffice.Page.ShowMessage.Page_ShowMessage_Detail;
import hf.iOffice.Page.ShowMessage.Page_ShowMessage_Discuss;
import hf.iOffice.Page.ShowMessage.ReceiveMessage.Page_ReceiveMessage_List;
import hf.iOffice.test.TestBase;

import android.test.suitebuilder.annotation.Smoke;

public class TestCase_ShowMessage_Discuss extends TestBase {

	public Page_DeskTop page_DeskTop;
	public Data_ShowMessage_Discuss data_ShowMessage_Discuss;
	public Page_ShowMessage_Menu page_ShowMessageMenu;
	public Page_ReceiveMessage_List page_ReceiveMessage_List;
	public Page_ShowMessage_Detail page_ShowMessage_Detail;
	public Page_ShowMessage_Discuss page_ShowMessage_Discuss;

	@Smoke
	public void testCase_ShowMessage_Discuss() throws Exception {
		data_ShowMessage_Discuss=new Data_ShowMessage_Discuss();
		page_LogOn = new Page_LogOn(solo,"TestCase_ShowMessage_Discuss");
		page_DeskTop = new Page_DeskTop(solo,"TestCase_ShowMessage_Discuss");
		page_ShowMessageMenu = new Page_ShowMessage_Menu(solo,"TestCase_ShowMessage_Discuss");
		page_ReceiveMessage_List = new Page_ReceiveMessage_List(solo,"TestCase_ShowMessage_Discuss");
		page_ShowMessage_Detail = new Page_ShowMessage_Detail(solo,"TestCase_ShowMessage_Discuss");
		page_ShowMessage_Discuss = new Page_ShowMessage_Discuss(solo,"TestCase_ShowMessage_Discuss");
		// 设置IP登录
		login(data_login.loginIP);
		page_LogOn.input_用户名(data_ShowMessage_Discuss.getValue_登录人()[0]);
		page_LogOn.input_密码(data_login.loginIdPwd1);
		page_LogOn.click_记住密码();
		page_LogOn.click_登录();

		// 点击普通传阅
		page_DeskTop.click_普通传阅();

		// 点击收到传阅
		page_ShowMessageMenu.click_收到传阅();

		// 点击全部传阅
		page_ReceiveMessage_List.click_全部传阅();

		// 点击第一条记录
		page_DeskTop.click_搜索(data_ShowMessage_Discuss.get_MsgSerInf()[0],"普通传阅");
		page_ReceiveMessage_List.click_记录(0,1);


		// 从数据库获取数据验证第一条记录信息
		// 点击Menu按钮,点击"发表传阅"按钮
		page_ShowMessage_Detail.click_发表讨论();
		page_ShowMessage_Discuss.input_讨论信息(data_ShowMessage_Discuss.get_讨论内容());
		data_ShowMessage_Discuss.set_发表讨论时间(page_ShowMessage_Discuss.click_发表(data_ShowMessage_Discuss.get_MsgSerInf()[0]));

		// 讨论页面验证
		page_ShowMessage_Detail.scollDownTo讨论();
		if (page_ShowMessage_Detail.assert_讨论(data_ShowMessage_Discuss.getValue_登录人()[2], data_ShowMessage_Discuss.get_发表讨论时间(), data_ShowMessage_Discuss.get_讨论内容())) {
			assertTrue(true);
		} else {
			assertTrue(data_ShowMessage_Discuss.getValue_记录错误信息(), false);
		}
		//讨论数据库验证
		if(data_ShowMessage_Discuss.assert_数据库验证()==1)
			assertTrue(true);
		else
			assertTrue(data_ShowMessage_Discuss.getValue_记录错误信息(), false);
	}
}
