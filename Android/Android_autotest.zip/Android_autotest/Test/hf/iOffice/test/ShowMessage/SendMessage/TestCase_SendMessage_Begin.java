package hf.iOffice.test.ShowMessage.SendMessage;
import hf.iOffice.Data.ShowMessage.SendMessage.Data_SendMessage_Begin;
import hf.iOffice.Page.Desktop.Page_DeskTop;
import hf.iOffice.Page.Login.Page_LogOn;
import hf.iOffice.Page.Login.Page_Setting;
import hf.iOffice.Page.ShowMessage.Page_ShowMessage_Detail;
import hf.iOffice.Page.ShowMessage.Page_ShowMessage_Menu;
import hf.iOffice.Page.ShowMessage.SendMessage.Page_SendMessage_List;
import hf.iOffice.test.TestBase;
import android.test.suitebuilder.annotation.Smoke;

public class TestCase_SendMessage_Begin extends TestBase{
	public Page_LogOn page_LogOn;
	public Page_Setting page_Setting;
	public Page_DeskTop page_DeskTop;
	public Page_ShowMessage_Menu page_ShowMessageMenu;
	public Page_SendMessage_List page_SendMessage_List;
	public Page_ShowMessage_Detail page_ShowMessage_Detail;
	public Data_SendMessage_Begin data_SendMessage_Begin;
	@Smoke
	public void testCase_SendMessage_Begin() throws Exception {
		data_SendMessage_Begin=new Data_SendMessage_Begin();
		page_LogOn=new Page_LogOn(solo,"TestCase_SendMessage_Begin");
		page_DeskTop=new Page_DeskTop(solo,"TestCase_SendMessage_Begin");
		page_ShowMessageMenu=new Page_ShowMessage_Menu(solo,"TestCase_SendMessage_Begin");
		page_SendMessage_List=new Page_SendMessage_List(solo,"TestCase_SendMessage_Begin");
		page_ShowMessage_Detail=new Page_ShowMessage_Detail(solo,"TestCase_SendMessage_Begin");
		//设置IP登录
		page_LogOn.input_用户名(data_SendMessage_Begin.getValue_登录人()[0]);
		page_LogOn.input_密码(data_login.loginIdPwd1);
		page_LogOn.click_记住密码();
		page_LogOn.click_登录();
		
		//点击普通传阅
		page_DeskTop.click_普通传阅();
		
		//点击发送传阅
		page_ShowMessageMenu.click_发送传阅();
		
		//点击已/开始传阅
		page_SendMessage_List.click_未已开始();
		//从数据库获取数据验证每一条记录信息

		int top10=data_SendMessage_Begin.getValue_预期传阅信息().size()/9;
		for (int i = 0; i < top10; i++) {
			//列表验证
			if(data_SendMessage_Begin.getValue_预期传阅信息().get(i*9+3).equals("-1"))
				assertEquals(data_SendMessage_Begin.getValue_记录错误信息(i),"(未开始)"+data_SendMessage_Begin.getValue_预期传阅信息().get(i*9),page_SendMessage_List.get_标题(i, top10));
			else
				assertEquals(data_SendMessage_Begin.getValue_记录错误信息(i),data_SendMessage_Begin.getValue_预期传阅信息().get(i*9),page_SendMessage_List.get_标题(i, top10));
			assertEquals(data_SendMessage_Begin.getValue_记录错误信息(i),data_SendMessage_Begin.getValue_预期传阅信息().get(i*9+1).substring(5, 16),page_SendMessage_List.get_发送时间(i, top10));
			assertEquals(data_SendMessage_Begin.getValue_记录错误信息(i),data_SendMessage_Begin.getValue_预期传阅信息().get(i*9+2),page_SendMessage_List.get_发送人(i, top10));
			String expectedContentString=subStringXML(data_SendMessage_Begin.getValue_预期传阅信息().get(i*9+4)).replaceAll("\n", "").replaceAll(" ", "");
			String actualContentString=page_SendMessage_List.get_内容(i, top10).replaceAll("\n", "").replaceAll(" ", "");
			if(expectedContentString.length()>actualContentString.length())
				assertEquals(data_SendMessage_Begin.getValue_记录错误信息(i),expectedContentString.substring(0, actualContentString.length()),actualContentString);
			else
				assertEquals(data_SendMessage_Begin.getValue_记录错误信息(i),expectedContentString,actualContentString.substring(0, expectedContentString.length()));
		
			//内容验证
			page_SendMessage_List.click_记录(i, top10);
			assertEquals(data_SendMessage_Begin.getValue_记录错误信息(i), data_SendMessage_Begin.getValue_预期传阅信息().get(i*9),page_ShowMessage_Detail.get_标题());
			assertEquals(data_SendMessage_Begin.getValue_记录错误信息(i), data_SendMessage_Begin.getValue_预期传阅信息().get(i*9+5),page_ShowMessage_Detail.get_发送时间());
			assertEquals(data_SendMessage_Begin.getValue_记录错误信息(i), data_SendMessage_Begin.getValue_预期传阅信息().get(i*9+6) + "/"+ data_SendMessage_Begin.getValue_预期传阅信息().get(i*9+2), page_ShowMessage_Detail.get_发送人());	
		
			//讨论信息验证
			data_SendMessage_Begin.setValue_预期讨论信息(i);
			if (data_SendMessage_Begin.getValue_讨论总数(i)!=0) {
				page_ShowMessage_Detail.scollDownTo讨论();
				for (int j = 0; j < data_SendMessage_Begin.getValue_预期讨论信息().size() / 4; j++) {
					if (page_ShowMessage_Detail.assert_讨论(
							data_SendMessage_Begin.getValue_预期讨论信息().get(j * 4),
							data_SendMessage_Begin.getValue_预期讨论信息().get(j * 4 + 1),
							data_SendMessage_Begin.getValue_预期讨论信息().get(j * 4 + 2))) {
						assertTrue(true);
					} else {
						assertTrue(data_SendMessage_Begin.getValue_讨论错误信息(i,j), false);
					}
				}
			}
			
			// 验证接收人的确认信息
			data_SendMessage_Begin.setValue_预期传阅人员信息(i);
			if (data_SendMessage_Begin.getValue_传阅人员总数(i)!=0) {
				page_ShowMessage_Detail.scollDownTo传阅人员();
				for (int j = 0; j < data_SendMessage_Begin.getValue_预期传阅人员信息().size() / 8; j++) {
					if (page_ShowMessage_Detail.get_传阅人员(
							data_SendMessage_Begin.getValue_预期传阅人员信息().get(j * 8 + 1),
							data_SendMessage_Begin.getValue_预期传阅人员信息().get(j * 8 + 2),
							data_SendMessage_Begin.getValue_预期传阅人员信息().get(j * 8 + 3))) {
						assertTrue(true);
					} else {
						assertTrue(data_SendMessage_Begin.getValue_传阅人员错误信息(i, j), false);
					}
				}
			}
			
			// 验证菜单按钮
			data_SendMessage_Begin.setValue_菜单列表(i);
			page_ShowMessage_Detail.click_Menu();
			String[] menu=page_ShowMessage_Detail.getMenu();
			assertTrue(data_SendMessage_Begin.getValue_菜单错误信息(i,0,6),page_ShowMessage_Detail.assert开始传阅(data_SendMessage_Begin.getValue_菜单列表()[0],data_SendMessage_Begin.getValue_菜单列表()[6],menu));
			assertTrue(data_SendMessage_Begin.getValue_菜单错误信息(i,1),page_ShowMessage_Detail.assert保存退出(data_SendMessage_Begin.getValue_菜单列表()[1],menu));
			assertTrue(data_SendMessage_Begin.getValue_菜单错误信息(i,2),page_ShowMessage_Detail.assert新增人员(data_SendMessage_Begin.getValue_菜单列表()[2],menu));
			assertEquals(data_SendMessage_Begin.getValue_菜单错误信息(i,3),data_SendMessage_Begin.getValue_菜单列表()[3],page_ShowMessage_Detail.assert重新确认());
			assertEquals(data_SendMessage_Begin.getValue_菜单错误信息(i,4),data_SendMessage_Begin.getValue_菜单列表()[4],page_ShowMessage_Detail.assert确认传阅());
			assertTrue(data_SendMessage_Begin.getValue_菜单错误信息(i,5),page_ShowMessage_Detail.assert发表讨论(data_SendMessage_Begin.getValue_菜单列表()[5],menu));
		}
		
		//总记录数验证
		if(data_SendMessage_Begin.getValue_总记录数()>10)
		{
			assertEquals(Integer.toString(data_SendMessage_Begin.getValue_总记录数()),page_SendMessage_List.get_记录总数());
		}
	}
}
