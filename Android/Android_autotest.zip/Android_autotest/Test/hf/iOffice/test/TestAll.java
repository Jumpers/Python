package hf.iOffice.test;
import hf.iOffice.test.ShowMessage.Operation.TestCase_ShowMessage_Discuss;
import hf.iOffice.test.ShowMessage.SendMessage.TestCase_SendMessage_Begin;
import junit.framework.Test;
import junit.framework.TestSuite;

public class TestAll {
	public static Test suite() {
		TestSuite suite = new TestSuite("TestSuite Test");
		suite.addTestSuite(TestCase_SendMessage_Begin.class);
		suite.addTestSuite(TestCase_ShowMessage_Discuss.class);
		return suite;
	}
}
