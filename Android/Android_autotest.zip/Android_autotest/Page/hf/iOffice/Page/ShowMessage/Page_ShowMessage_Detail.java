package hf.iOffice.Page.ShowMessage;
import android.widget.Button;

import com.jayway.android.robotium.solo.Solo;

import hf.iOfficeHD.R;
import hf.iOffice.Page.BitmapShotActivity;
import hf.iOffice.Page.Page;

public class Page_ShowMessage_Detail  extends Page{	
	public Page_ShowMessage_Detail(Solo solo,String testcase) throws InterruptedException {
	super(solo);
	this.testcase=testcase;
	this.page="Page_ShowMessage_Detail";
	}
	public int value_当前列表位置;

	public Page_ShowMessage_Detail(Solo solo) throws Exception {
		super(solo);
		solo.sleep(2000);
		value_当前列表位置=100;
		this.page="Page_ShowMessage_Detail";
	}

	public String get_标题() throws Exception{
		for (int i = 0; i < 5; i++)
			try {
				return solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(0).getText().toString();
			} catch (Exception e) {
				BitmapShotActivity.takeScreenShot(solo.getCurrentListViews().get(1), testcase, page);
				System.out.println(e);
				solo.sleep(500);
			}
		return "出错...";
	}
	
	public String get_发送时间() throws Exception{
		for (int i = 0; i < 5; i++)
			try {
				return solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(2).getText().toString();
			} catch (Exception e) {
				BitmapShotActivity.takeScreenShot(solo.getCurrentListViews().get(1), testcase, page);
				System.out.println(e);
				solo.sleep(500);
			}
		return "出错...";
	}
	
	public String get_发送人() throws Exception{
		for (int i = 0; i < 5; i++)
			try {
				if(!solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(4).getText().toString().contains("/"))
					return "/"+solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(4).getText().toString();
				else
					return solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(4).getText().toString();
			} catch (Exception e) {
				BitmapShotActivity.takeScreenShot(solo.getCurrentListViews().get(1), testcase, page);
				System.out.println(e);
				solo.sleep(500);
			}
		return "出错...";
	}
	
	public void click_Menu(){
		solo.sendKey(82);
		solo.sleep(1000);
	}
	
	public void click_发表讨论(){
		for (int i = 0; i < 10; i++)
			try {
				solo.clickOnMenuItem("发表讨论");
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
	}
	
	public String click_确认传阅() throws Exception{
		String currentDate="";
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnView(solo.getCurrentActivity().findViewById(R.id.btnListWithInput));
				currentDate=getCurrentDate();
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		solo.sleep(1500);
		waittingMode("普通传阅");
		return currentDate;
	}
	
	public void input_确认内容(String confirmcontent){
		for (int i = 0; i < 5; i++)
			try {
				solo.clearEditText(1);
				solo.enterText(1, confirmcontent);
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(500);
			}
	}
	
	public String click_重新确认() throws Exception{
		String currentDate="";
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnView(solo.getCurrentActivity().findViewById(R.id.btnListWithInput));
				currentDate=getCurrentDate();
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		solo.sleep(1500);
		waittingMode("普通传阅");
		return currentDate;
	}
	
	public String click_确认为已阅() throws Exception{
		String currentDate="";
		for (int i = 0; i < 10; i++)
			try {		
				solo.clickOnView(solo.getCurrentActivity().findViewById(R.id.btnListWithInput));
				currentDate=getCurrentDate();
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
		return currentDate;
	}
	
	public void click_新增人员() throws Exception{
		for (int i = 0; i < 10; i++)
			try {
				solo.clickOnMenuItem("新增人员");
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode( "人员选择");
	}
	
	public String click_开始传阅() throws Exception{
		String currentDate="";
		for (int i = 0; i < 10; i++)
			try {
				solo.clickOnMenuItem("开始传阅");
				currentDate=getCurrentDate();
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
		return currentDate;
	}
	
	public boolean search_确认传阅(){
		return solo.searchText("确认传阅");
	}
	
	public boolean search_确认为已阅(){
		return solo.searchText("确认为已阅");
	}
	
	public boolean search_新增人员(){
		return solo.searchText("新增人员");
	}
	
	public boolean search_发表讨论(){
		return solo.searchText("发表讨论");
	}
	
	public boolean search_重新确认(){
		return solo.searchText("重新确认");
	}
	
	public boolean search_开始传阅(){
		
		return solo.searchText("开始传阅");
	}
	
	public boolean search_保存退出(){
		return solo.searchText("保存退出");
	}
	
	public boolean assertMenu(String[] status){
		boolean assertMenu=true;
		//status[0]==0非我发送的,不存在开始传阅菜单
		if (status[0].equals("0")) {
			if (search_开始传阅())
				assertMenu = false;
		} 
		//status[0]==1我发送的
		else {
			//status[6]==0没有已确认的传阅,存在开始传阅菜单
			if (status[6].equals("0")) {
				if (!search_开始传阅())
					assertMenu = false;
			}
			//status[6]>0已存在已确认的传阅,不存在开始传阅菜单
			else {
				if (search_开始传阅())
					assertMenu = false;
			}
		}
		
		if(status[1].equals("1")){
			if(!search_保存退出())
				assertMenu=false;
		}
		else {
			if(search_保存退出())
				assertMenu=false;
		}
		
		if(status[2].equals("1")){
			if(!search_新增人员())
				assertMenu=false;
		}
		else {
			if(search_新增人员())
				assertMenu=false;
		}
		
		if(status[3].equals("1")){
			if(!search_重新确认())
				assertMenu=false;
		}
		else {
			if(search_重新确认())
				assertMenu=false;
		}
		
		if(status[4].equals("1")){
			if(!search_确认传阅()||!search_确认为已阅())
				assertMenu=false;
		}
		else {
			if(search_确认传阅())
				assertMenu=false;
		}
		if(status[5].equals("1")){
			if(!search_发表讨论())
				assertMenu=false;
		}
		else {
			if(search_发表讨论())
				assertMenu=false;
		}
		return assertMenu;
	}
	
	public String[] getMenu() {
		for (int i = 0; i < 5; i++)
			try {
				String[] menu = { "", "", "", "", "", "","" };
				int size = (solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).size())/2;
				if(size>5)
					size=5;
				for (int j = 0; j < size; j++) {
					menu[j] = solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(j*2).getText().toString();
				}
				solo.goBack();
				return menu;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(500);
			}
		return null;
	}
	
	public boolean assert开始传阅(String status1, String status2, String[] menu) {
		//status[0]==0非我发送的,不存在开始传阅菜单
		if (status1.equals("0")) {
			for (int i = 0; i < 5; i++) {
				if ("开始传阅".equals(menu[i]))
					return false;
			}
			return true;
		} else {
			//status[6]==0没有已确认的传阅,存在开始传阅菜单
			if (status2.equals("0")) {
				for (int i = 0; i < 5; i++) {
					if ("开始传阅".equals(menu[i]))
						return true;
				}
				return false;
			}
			//status[6]>0已存在已确认的传阅,不存在开始传阅菜单
			else {
				for (int i = 0; i < 5; i++) {
					if ("开始传阅".equals(menu[i]))
						return false;
				}
				return true;
			}
		}
	}
	
	public boolean assert保存退出(String status, String[] menu) {
		if (status.equals("1")) {
			for (int i = 0; i < 5; i++) {
				if ("保存".equals(menu[i]))
					return true;
			}
			return false;
		} else {
			for (int i = 0; i < 5; i++) {
				if ("保存".equals(menu[i]))
					return false;
			}
			return true;
		}
	}
	
	public boolean assert发表讨论(String status, String[] menu) {
		if (status.equals("1")) {
			for (int i = 0; i < 5; i++) {
				if ("发表讨论".equals(menu[i]))
					return true;
			}
			return false;
		} else {
			for (int i = 0; i < 5; i++) {
				if ("发表讨论".equals(menu[i]))
					return false;
			}
			return true;
		}
	}
	
	public String assert重新确认() {
		try{
			Button btn=(Button) solo.getCurrentActivity().findViewById(R.id.btnListWithInput);
			if(btn.getText().toString().equals("重新确认传阅")&&btn.isShown())
				return "1";
			else
				return "0";
		}
		catch (Exception e) {
			System.out.println(e);
			return "0";
		}
	}
	
	public String assert确认传阅() {
		try{
			Button btn=(Button) solo.getCurrentActivity().findViewById(R.id.btnListWithInput);
			if(btn.getText().toString().equals("确认传阅")&&btn.isShown())
				return "1";
			else
				return "0";
		}
		catch (Exception e) {
			System.out.println(e);
			return "0";
		}
	}
	
	public boolean assert已阅() {
		int size=solo.getCurrentEditTexts().size();
		for(int j=0;j<size-1;j++)
			try{
				return solo.getCurrentEditTexts().get(0).getText().toString().equals("已阅");
			}
			catch (Exception e) {
				System.out.println(e);
			}
		return false;
	}
	
	public boolean assert新增人员(String status, String[] menu) {
		if (status.equals("1")) {
			for (int i = 0; i < 5; i++) {
				if ("新增人员".equals(menu[i]))
					return true;
			}
			return false;
		} else {
			for (int i = 0; i < 5; i++) {
				if ("新增人员".equals(menu[i]))
					return false;
			}
			return true;
		}
	}
	
	public void scollDownTo传阅人员() throws Exception{
		boolean search传阅人员=false;
		for(int j=0;j<10;j++){
			int size=solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).size();
			for(int i=0;i<size;i++)
			{
				if(solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i).getText().toString().equals("传阅人员"))
				{
					value_当前列表位置=i+1;
					search传阅人员=true;
					break;
				}
			}
			if(search传阅人员)
				break;
			else{
				solo.scrollDownList(1);
				solo.sleep(1000);
			}
		}
		BitmapShotActivity.takeScreenShot(solo.getCurrentListViews().get(1), testcase, "Page_ShowMessage_Detail");
	}
	
	public void scollDownTo讨论() throws Exception{
		boolean search讨论=false;
		for(int j=0;j<6;j++){
			int size=solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).size();
			for(int i=0;i<size;i++)
			{
				if(solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i).getText().toString().equals("讨论"))
				{
					value_当前列表位置=i+1;
					search讨论=true;
					break;
				}
			}
			if(search讨论)
				break;
			else{
				solo.scrollDownList(1);
				solo.sleep(1000);
			}
		}
		BitmapShotActivity.takeScreenShot(solo.getCurrentListViews().get(1), testcase, "Page_ShowMessage_Detail");
	}
	
	public boolean assertBUG386(String name){
		while(solo.scrollDownList(1)){
				solo.sleep(1000);
		}
		int size=solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).size();
		for(int i=4;i>2;i--)
		{
			if(solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(size-i).getText().toString().equals("传阅人员"))
				if(solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(size-i+1).getText().toString().equals(name))
					return true;
				else 
					return false;
		}
		return false;
	}
	
	public void scollDownTo附件下载(){
		while(true){
			if(solo.searchText("附件"))
				break;
			if(!solo.scrollDownList(1)){
				solo.sleep(1000);
				break;
			}
		}
	}
	
	//已确认,不含"<>"标签的
	public boolean assert_传阅人员1(String name, String status, String note,int i){
		try{
			if (solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i).getText().toString().equals(name)
					&& solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i + 1).getText().toString().equals(status)
					&& solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i + 2).getText().toString().contains(note)){
				value_当前列表位置=i+3;
				return true;
			}
		}
		catch (Exception e) {
			System.out.println(e);
			return false;
		}
		return false;
	}
	// 已确认,含"<>"标签的,把含有"<>"截取成两半,对左边的验证是否包含在页面获取的里面,做循环直到截取不到"<>"为止,最后截再对右边的部分验证
	public boolean assert_传阅人员2(String name, String status, String note,int i){
		try{
			if (solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i).getText().toString().equals(name)
					&& solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i + 1).getText().toString().equals(status)) {
				boolean noteContain = true;
				String noteleft = "";
				String noteright = note;
				while ((noteright.contains("<") && noteright.contains(">"))) {
					noteleft = noteright.substring(0,noteright.indexOf("<"));
					noteright = noteright.substring(noteright.indexOf(">") + 1);
					if (!solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i + 2).getText().toString().contains(noteleft))
						noteContain = false;
				}
				if (!solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i + 2).getText().toString().contains(noteright))
					noteContain = false;
				if (noteContain == true)
				{
					value_当前列表位置=i+3;
					return true;
				}
			}
		}
		catch (Exception e) {
			System.out.println(e);
			return false;
		}
		return false;
	}
	//未确认的
	public boolean assert_传阅人员3(String name, String status, String note,int i){
		try{
			if (solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i).getText().toString().equals(name)
					 && solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i + 1).getText().toString().equals(status)){
				value_当前列表位置=i+3;
				return true;
			}
		}
		catch (Exception e) {
			System.out.println(e);
			return false;
		}
		return false;
	}

	
	public boolean get_传阅人员(String name, String status, String note) throws Exception{
		int size=solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).size();
		if(value_当前列表位置<size-2){
			// 已确认
			if(status.contains("已确认")){
				if (status.contains("<") && status.contains(">")) {
					while ((status.contains("<") && status.contains(">"))) {
						status = status.substring(0, status.indexOf("<"))+ " "+ status.substring(status.indexOf(">") + 1);
					}				
				}
				if(!note.isEmpty()&&(!note.equals(page)&&note.contains("\n")))
					note=note.replaceAll("\n", "");
				if (!note.isEmpty()&&!(note.contains("<") && note.contains(">"))) {
					return assert_传阅人员1(name,status,note,value_当前列表位置);
				}
				else{
					return assert_传阅人员2(name,status,note,value_当前列表位置);
				}
			}
			else{
				return assert_传阅人员3(name,status,note,value_当前列表位置);
			}
		}
		else{
			solo.scrollDownList(1);
			solo.sleep(2000);
			BitmapShotActivity.takeScreenShot(solo.getCurrentListViews().get(1), testcase, "Page_ShowMessage_Detail");
			size=solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).size();
			if (status.contains("已确认")) {
				if (status.contains("<") && status.contains(">")) {
					while ((status.contains("<") && status.contains(">"))) {
						status = status.substring(0, status.indexOf("<"))+ " "+ status.substring(status.indexOf(">") + 1);
					}
				}
				for (int i = 0; i < size - 2; i++) {
					if (!note.isEmpty()&&!(note.contains("<") && note.contains(">"))) {
						if(assert_传阅人员1(name,status,note,i))
							return true;
					}
					else{
						if(assert_传阅人员2(name,status,note,i))
							return true;
					}
				}
			}
			else{
				for(int i=0;i<size-1;i++){
					if(assert_传阅人员3(name,status,note,i))
						return true;
				}
			}
		}
		return false;
	}

	public boolean assertConfirm(String name,String time,String note) throws Exception{
		//首先在当前页搜索,如果搜索到就返回,否则翻页再搜索,最多三次翻页
		scollDownTo传阅人员();
		for(int j=0;j<10;j++)
		{
			for(int i=0;i<solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).size()-2;i++)
			{
				if(solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i).getText().toString().equals(name)
						&&solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i+1).getText().toString().contains("已确认  "+time)
						&&solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i+2).getText().toString().contains(note))
						return true;
			}
			solo.scrollDownList(1);
			solo.sleep(1000);
		}
		return false;
	}
	
	public boolean assert_讨论(String name, String time, String content) throws Exception {
		//首先在当前页搜索,如果搜索到就返回,否则翻页再搜索,最多三次翻页
		for(int j=0;j<3;j++)
		{
		for (int i = 0; i < solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).size() - 3; i++) {
			if (solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i).getText().toString().equals(name)
					&& solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i + 2).getText().toString().contains(time)
					&& solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i + 3).getText().toString().equals(content)){
				return true;
				}
		}
		if(!solo.scrollDownList(1)){
			BitmapShotActivity.takeScreenShot(solo.getCurrentListViews().get(1), testcase, "Page_ShowMessage_Detail");
			solo.sleep(1000);
			return false;
		}
		}
		return false;
	}
	
	public boolean get_附件下载(String name) throws Exception{
		// 首先在当前页搜索,如果搜索到就返回,否则翻页再搜索,最多三次翻页
		BitmapShotActivity.takeScreenShot(solo.getCurrentListViews().get(1), testcase, "Page_ShowMessage_Detail");
		for (int j = 0; j < 3; j++) {
			for (int i = 0; i < solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).size() - 1; i++) {
				if (solo.getCurrentTextViews(solo.getCurrentListViews().get(1)).get(i).getText().toString().equals(name))
					return true;
			}
			if(!solo.scrollDownList(1)){
				solo.sleep(1000);
				return false;
			}
		}
		return false;
	}
}
