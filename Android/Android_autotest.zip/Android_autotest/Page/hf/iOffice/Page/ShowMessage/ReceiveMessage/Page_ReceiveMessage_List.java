package hf.iOffice.Page.ShowMessage.ReceiveMessage;

import hf.iOfficeHD.R;
import hf.iOffice.Page.ShowMessage.Page_ShowMessage_List;

import com.jayway.android.robotium.solo.Solo;

public class Page_ReceiveMessage_List extends Page_ShowMessage_List{	
	public Page_ReceiveMessage_List(Solo solo,String testcase) throws InterruptedException {
		super(solo);
		this.testcase = testcase;
		this.page = "Page_ReceiveMessage_List";
	}
	public Page_ReceiveMessage_List(Solo solo) throws InterruptedException {
		super(solo);
		this.page="Page_ReceiveMessage_List";
	}

	public void click_未确认传阅() throws Exception{
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnButton("未确认");
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
	
	public void click_已确认传阅() throws Exception{
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnButton("已确认");
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
	
	public void click_全部传阅() throws Exception{
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnButton("全部");
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
	
	public void click_快速传阅() throws Exception{
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnView(solo.getCurrentActivity().findViewById(R.id.menu_msg_fast_processing));
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅快速处理");
	}
}
