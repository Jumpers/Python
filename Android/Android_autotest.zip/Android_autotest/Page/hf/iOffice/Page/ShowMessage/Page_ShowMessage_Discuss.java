package hf.iOffice.Page.ShowMessage;

import com.jayway.android.robotium.solo.Solo;

import hf.iOffice.Page.Page;

public class Page_ShowMessage_Discuss  extends Page{
	public Page_ShowMessage_Discuss(Solo solo,String testcase) throws InterruptedException {
		super(solo);
		this.testcase=testcase;
		this.page="Page_ShowMessage_Discuss";
	}

	public Page_ShowMessage_Discuss(Solo solo) throws InterruptedException {
		super(solo);
		this.page="Page_ShowMessage_Discuss";
	}

	public void input_讨论信息(String discuss){
		for (int i = 0; i < 10; i++)
			try {
				solo.enterText(0, discuss);
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
	}
	
	public String click_发表(String title) throws Exception{
		String currentDate="";
		solo.sleep(1000);
		for (int i = 0; i < 10; i++)
			try {
				solo.clickOnButton("发表");
				currentDate=getCurrentDate();
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		solo.sleep(1500);
		waittingMode("普通传阅");
		return currentDate;
	}
}
