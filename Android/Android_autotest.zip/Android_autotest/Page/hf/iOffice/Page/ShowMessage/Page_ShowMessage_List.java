package hf.iOffice.Page.ShowMessage;
import com.jayway.android.robotium.solo.Solo;

import hf.iOffice.Page.BitmapShotActivity;
import hf.iOffice.Page.Page;

public class Page_ShowMessage_List extends Page{	
	public Page_ShowMessage_List(Solo solo,String testcase) throws InterruptedException {
	super(solo);
	this.testcase=testcase;
	}
	public int onePageListNum=0;

	public Page_ShowMessage_List(Solo solo) throws InterruptedException {
		super(solo);
	}
	
	public String click_记录(int i,int firstPageListCount) throws Exception {
		int size=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).size();
		onePageListNum=size/4;
		if(size%4==0&&onePageListNum!=firstPageListCount)
			onePageListNum=onePageListNum-1;
		if((firstPageListCount-1)/onePageListNum*onePageListNum>i||firstPageListCount==1)
		{
			for(int a=0;a<10;a++)
				try {
					solo.clickOnView(solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get((i%onePageListNum)*4));
					break;
				} catch (Exception e) {
					System.out.println(e);
					solo.sleep(1000);
				}
		}
		else if(!(solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString().contains("共")&&solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString().contains("项")))
		{
			for(int a=0;a<10;a++)
				try {
					solo.clickOnView(solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-(firstPageListCount-i-1)*4-4));
					break;
				} catch (Exception e) {
					System.out.println(e);
					solo.sleep(1000);
				}
		}
		else
		{
			for(int a=0;a<10;a++)
				try {
					solo.clickOnView(solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-(firstPageListCount-i-1)*4-4-2));
					break;
				} catch (Exception e) {
					System.out.println(e);
					solo.sleep(1000);
				}
		}
		String currentDate=getCurrentDate();
		waittingMode("普通传阅");
		solo.sleep(1000);
		return currentDate;
	}

	public String click_记录(String title,int tabIndex) throws Exception {	
		solo.sleep(1000);
		for(int i=0;i<solo.getCurrentTextViews(solo.getCurrentListViews().get(tabIndex)).size()-3;i++)
		{
			if(solo.getCurrentTextViews(solo.getCurrentListViews().get(tabIndex)).size()==i*4)
				System.out.println("标题为:"+title+"第"+i+"条数据");
			if(solo.getCurrentTextViews(solo.getCurrentListViews().get(tabIndex)).get(i*4).getText().toString().equals(title))
			{
				solo.clickOnView(solo.getCurrentTextViews(solo.getCurrentListViews().get(tabIndex)).get(i*4));
				break;
			}
				
		}
//		for(int i=0;i<10&&!solo.searchText(title);i++)
//			solo.sleep(500);
//		solo.clickOnText(title);
		String currentDate=getCurrentDate();
		solo.sleep(2000);
		waittingMode("普通传阅");
		return currentDate;
	}

	public String get_标题(int i,int firstPageListCount) throws Exception{
		String 标题="";
		try {
			int size=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).size();
			onePageListNum=size/4;
			if(size%4==0&&onePageListNum!=firstPageListCount)
				onePageListNum=onePageListNum-1;
			if(i==0)
				BitmapShotActivity.takeScreenShot(solo.getCurrentListViews().get(0), testcase, "Page_ShowMessage_List");
			if((i%onePageListNum==0&&i!=0))
			{
				solo.scrollDownList(0);
				solo.sleep(500);
				BitmapShotActivity.takeScreenShot(solo.getCurrentListViews().get(0), testcase, "Page_ShowMessage_List");
				size=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).size();
			}
			if((firstPageListCount-1)/onePageListNum*onePageListNum>i||firstPageListCount==1)
				标题=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get((i%onePageListNum)*4).getText().toString();
			else if(!(solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString().contains("共")&&solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString().contains("项")))
				标题=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-(firstPageListCount-i-1)*4-4).getText().toString();
			else
			{
				
				标题=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-(firstPageListCount-i-1)*4-4-2).getText().toString();
			}
		} catch (Exception e) {
			标题="出错.......";
			System.out.println(e);
		}
		return 标题;
	}
	
	public String get_记录总数() throws Exception{
		int size=0;
		String countString="";
		for(int i=0;i<10;i++)
		{
			solo.scrollDownList(0);
			size=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).size();
			countString=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString();
			if(countString.contains("共")&&countString.contains("项")&&countString.contains("页"))
				return countString.substring(1,countString.indexOf("项"));
		}
		return "";
	}
	
	public String get_传阅查询记录总数() throws Exception{
		int size = solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).size();
		if(size/4==0)
			return Integer.toString(0);
		int onePageListNum=size/4;
		String[] lastPageLastSCate={"","","","","","","","","",""};
		String[] lastPageLastTitle={"","","","","","","","","",""};
		lastPageLastSCate[0]=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get((onePageListNum-1)*4+3).getText().toString();
		lastPageLastTitle[0]=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get((onePageListNum-1)*4).getText().toString();
		String currentSCate="";
		String currentTitle="";
		String lastTitle=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString();
		String lastSCate=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-4).getText().toString();
		int i=0;
		for(;i<10;i++)
		{
			scrollDown();
			size = solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).size();
			onePageListNum=size/4;
			if(lastTitle.equals(solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString())
					&&lastSCate.equals(solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-4).getText().toString())){
				if(i==0)
					return Integer.toString(onePageListNum);
				else {
					String title1 = solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size - 1).getText().toString();
					if(title1.contains("共")&&title1.contains("项")&&title1.contains("页"))
						return title1.substring(1,title1.indexOf("项"));
					else {
						for (int j = onePageListNum-1; j >0; j--) {
							currentSCate=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get((size-(onePageListNum-j)*4)-1).getText().toString();
							currentTitle=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get((size-(onePageListNum-j)*4)-4).getText().toString();
							if(currentSCate.equals(lastPageLastSCate[i-1])&&currentTitle.equals(lastPageLastTitle[i-1]))
								return Integer.toString(onePageListNum*(i)+(onePageListNum-j));							
						}
						return Integer.toString(onePageListNum*(i+1));
					}
				}
			}
			else{
				size = solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).size();
				onePageListNum=size/4;
				lastPageLastSCate[i+1]=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get((onePageListNum-1)*4+3).getText().toString();
				lastPageLastTitle[i+1]=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get((onePageListNum-1)*4).getText().toString();
				lastTitle=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString();
				lastSCate=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-4).getText().toString();
			}
		}
		return "";
	}

	public String get_BUG383记录(){
		int size = solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).size();
		if(size<2)
			return "";
		while(scrollDown())
			size = solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).size();
		String title = solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size - 2).getText().toString();
		return title;
	}
	
	public String get_发送时间(int i,int firstPageListCount){
		int size=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).size();
		String 公共时间="";
		if((firstPageListCount-1)/onePageListNum*onePageListNum>i||firstPageListCount==1)
			公共时间=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get((i%onePageListNum)*4+3).getText().toString();
		else if(!(solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString().contains("共")&&solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString().contains("项")))
			公共时间=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-(firstPageListCount-i-1)*4-1).getText().toString();
		else
			公共时间=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-(firstPageListCount-i-1)*4-1-2).getText().toString();
		return 公共时间;
	}
	
	public String get_发送人(int i,int firstPageListCount){
		int size=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).size();
		String 发送人="";
		if((firstPageListCount-1)/onePageListNum*onePageListNum>i||firstPageListCount==1)
			发送人=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get((i%onePageListNum)*4+2).getText().toString();
		else if(!(solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString().contains("共")&&solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString().contains("项")))
			发送人=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-(firstPageListCount-i-1)*4-2).getText().toString();
		else
			发送人=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-(firstPageListCount-i-1)*4-2-2).getText().toString();
		return 发送人;
	}
	
	public String get_内容(int i,int firstPageListCount){
		int size=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).size();
		String 内容="";
		if((firstPageListCount-1)/onePageListNum*onePageListNum>i||firstPageListCount==1)
			内容=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get((i%onePageListNum)*4+1).getText().toString();
		else if(!(solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString().contains("共")&&solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-1).getText().toString().contains("项")))
			内容=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-(firstPageListCount-i-1)*4-3).getText().toString();
		else
			内容=solo.getCurrentTextViews(solo.getCurrentListViews().get(0)).get(size-(firstPageListCount-i-1)*4-3-2).getText().toString();
		if (内容.length() > 6) {
			if (内容.substring(内容.length() - 5, 内容.length()).equals("&nbsp"))
				内容 = 内容.substring(0, 内容.length() - 5);
			if (内容.substring(内容.length() - 4, 内容.length()).equals("&nbs"))
				内容 = 内容.substring(0, 内容.length() - 4);
			if (内容.substring(内容.length() - 3, 内容.length()).equals("&nb"))
				内容 = 内容.substring(0, 内容.length() - 3);
			if (内容.substring(内容.length() - 2, 内容.length()).equals("&n"))
				内容 = 内容.substring(0, 内容.length() - 2);
			if (内容.substring(内容.length() - 1, 内容.length()).equals("&"))
				内容 = 内容.substring(0, 内容.length() - 1);
		}
		return 内容;
	}
	
	public void click_搜索(String title) throws Exception {
		for(int a=0;a<10;a++)
			try {
				solo.clickOnMenuItem("搜索");
				solo.enterText(0, title);
				solo.clickOnButton(0);
				solo.sleep(3000);
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
	
	public void 不点击搜索按钮搜索(String title) throws Exception {
		for(int a=0;a<10;a++)
			try {
				solo.clickOnMenuItem("搜索");
				solo.enterText(0, title);
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
}
