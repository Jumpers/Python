package hf.iOffice.Page.ShowMessage.SendMessage;

import hf.iOffice.Page.ShowMessage.Page_ShowMessage_List;

import com.jayway.android.robotium.solo.Solo;

public class Page_SendMessage_List  extends Page_ShowMessage_List {
	public Page_SendMessage_List(Solo solo,String testcase) throws InterruptedException {
		super(solo);
		this.testcase=testcase;
		this.page="Page_ReceiveMessage_List";
	}
	public Page_SendMessage_List(Solo solo) throws InterruptedException {
		super(solo);
		this.page="Page_ReceiveMessage_List";
	}
	
	public void click_未已开始() throws Exception{
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnButton("未/已开始");
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
	
	public void click_传阅中() throws Exception{
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnButton("传阅中");
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
	
	public void click_全部传阅() throws Exception{
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnButton("全部");
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
}
