package hf.iOffice.Page.ShowMessage;

import hf.iOffice.Page.Page;

import com.jayway.android.robotium.solo.Solo;

public class Page_ShowMessage_Menu extends Page {
	public Page_ShowMessage_Menu(Solo solo,String testcase) throws InterruptedException {
		super(solo);
		this.testcase=testcase;
		this.page="Page_ShowMessage_Menu";
	}

	public Page_ShowMessage_Menu(Solo solo) throws InterruptedException {
		super(solo);
	}
	public void click_收到传阅() throws Exception{
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnView(solo.getText("收到传阅"));
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
	
	public void click_发送传阅() throws Exception{
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnView(solo.getText("发送传阅"));
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
	
	public void click_传阅中() throws Exception{
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnView(solo.getText("传阅中"));
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
	
	public void click_已完成传阅() throws Exception{
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnView(solo.getText("已完成传阅"));
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
	
	public void click_查询传阅() throws Exception{
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnView(solo.getText("查询传阅"));
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
	
	public void click_新增传阅() throws Exception{
		for (int i = 0; i < 10; i++) 
			try {
				solo.clickOnView(solo.getText("新增传阅"));
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode("普通传阅");
	}
}
