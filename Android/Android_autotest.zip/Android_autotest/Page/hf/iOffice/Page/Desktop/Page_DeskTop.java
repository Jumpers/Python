package hf.iOffice.Page.Desktop;
import hf.iOfficeHD.R;
import hf.iOffice.Page.Page;
import com.jayway.android.robotium.solo.Solo;

public class Page_DeskTop extends Page {
	public Page_DeskTop(Solo solo,String testcase) throws InterruptedException {
		super(solo);
		this.testcase=testcase;
		this.page="Page_DeskTop";
	}

	public Page_DeskTop(Solo solo) throws InterruptedException {
		super(solo);
		this.page="Page_DeskTop";
	}

	public String getIoffice(){
		return solo.getText(0).getText().toString();
	}
	
	// 验证主页面菜单
	public Boolean checkDeskTop() throws Exception{
		for (int i = 0; i < 9; i++) {
			try {
				solo.searchText("关于 iOffice");
				return true;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		}
		return false;
	}

	public void click_普通传阅() throws Exception{
		for (int i = 0; i < 10; i++) 
		try {
//			int count=solo.getCurrentActivity().getActionBar().getTabCount();
//			for(int j=0;j<count;j++){
//				if(solo.getCurrentActivity().getActionBar().getTabAt(j).getText().equals("普通传阅")){
//					solo.getCurrentActivity().getActionBar().selectTab(solo.getCurrentActivity().getActionBar().getTabAt(j));
//				}
//			}
			solo.clickOnText("普通传阅");
			break;
		} catch (Exception e) {
			System.out.println(e);
			solo.sleep(1000);
		}
		waittingDeskTop();
	}
	
	public void click_通知公告() throws Exception{
		for (int i = 0; i < 10; i++) 
		try {
			solo.clickOnText("通知公告");
			break;
		} catch (Exception e) {
			System.out.println(e);
			solo.sleep(1000);
		}
		waittingDeskTop();
	}
	public void click_待办流程() throws Exception{
		for (int i = 0; i < 10; i++) 
		try {
			solo.clickOnText("待办流程");
			break;
		} catch (Exception e) {
			System.out.println(e);
			solo.sleep(1000);
		}
		waittingDeskTop();
	}
	public void click_设置() throws Exception{
		for (int i = 0; i < 10; i++) 
		try {
			solo.clickOnText("设置");
			break;
		} catch (Exception e) {
			System.out.println(e);
			solo.sleep(1000);
		}
		waittingDeskTop();
	}
	
	public void click_通讯录() throws Exception{
		for (int i = 0; i < 10; i++) 
		try {
			solo.clickOnText("通讯录");
			break;
		} catch (Exception e) {
			System.out.println(e);
			solo.sleep(1000);
		}
		waittingDeskTop();
	}
	
	public void click_在线对话() throws Exception{
		for (int i = 0; i < 10; i++) 
		try {
			solo.clickOnText("在线对话");
			break;
		} catch (Exception e) {
			System.out.println(e);
			solo.sleep(1000);
		}
		waittingDeskTop();
	}

	
	public void click_搜索(String search,String mode) throws Exception{
		try {
			solo.clickOnView(solo.getCurrentActivity().findViewById(R.id.menu_search));
		} catch (Exception e) {
			System.out.println(e);
			solo.sleep(1000);
		}
		int edittextsize = solo.getCurrentEditTexts().size();
		for (int j = 0; j < edittextsize; j++)
			try {
				if (solo.getCurrentEditTexts().get(j).getContentDescription().equals("搜索查询")) {
					solo.clearEditText(solo.getCurrentEditTexts().get(j));
					solo.enterText(solo.getCurrentEditTexts().get(j), search);
					solo.sleep(2000);
					break;
				}
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingMode(mode);
	}
	public void click_关于iOffice() throws Exception{
		for (int i = 0; i < 10; i++) 
		try {
			solo.clickOnText("关于iOffice");
			break;
		} catch (Exception e) {
			System.out.println(e);
			solo.sleep(1000);
		}
		waittingDeskTop();
	}
}
