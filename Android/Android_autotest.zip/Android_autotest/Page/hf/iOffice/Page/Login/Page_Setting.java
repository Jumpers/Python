package hf.iOffice.Page.Login;

import hf.iOffice.Page.Page;

import com.jayway.android.robotium.solo.Solo;

public class Page_Setting extends Page {
	public Page_Setting(Solo solo,String testcase) throws InterruptedException {
		super(solo);
		this.testcase=testcase;
		this.page="Page_Setting";
	}

	public Page_Setting(Solo solo) throws InterruptedException {
		super(solo);
		this.page="Page_Setting";
	}

	public void input_服务地址(String IP) {
		solo.clearEditText(0);
		solo.enterText(0, IP);
	}

	public void select_服务地址(String IP) {
		String currentHistoryIp = solo.getText(4).getText().toString();
		solo.clearEditText(0);
		solo.clickOnMenuItem(currentHistoryIp);
		solo.clickOnMenuItem(IP);
	}

	public void clear_服务地址() {
		solo.clearEditText(0);
	}

	public String get_服务地址() {
		return solo.getEditText(0).getText().toString();
	}

	public void click_确定() throws Exception {
		solo.clickOnButton("确定");
		waittingDeskTop();
	}

	public String get_提示信息() throws Exception {
		return solo.getText(0).getText().toString();
	}
}
