package hf.iOffice.Page.Login;
import hf.iOffice.Page.Page;

import com.jayway.android.robotium.solo.Solo;

public class Page_LogOn extends Page {
	public Page_LogOn(Solo solo,String testcase) throws InterruptedException {
		super(solo);
		this.testcase=testcase;
		this.page="Page_LogOn";
	}
	public Page_LogOn(Solo solo) throws InterruptedException {
		super(solo);
		this.page="Page_LogOn";
	}

	// 登录--非测试用
	public void input_用户名(String LoginName) throws Exception {
		for (int i = 0; i < 10; i++) 
		try {
			solo.clearEditText(0);
			solo.enterText(0, LoginName);
			break;
		} catch (Exception e) {
			System.out.println(e);
			solo.sleep(1000);
		}
	}

	public String get_用户名() {
		for (int i = 0; i < 5; i++)
			try {
				return solo.getEditText(0).getText().toString();
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(500);
			}
		return "出错...";
	}

	public void input_密码(String LoginPWD) throws Exception {
		for (int i = 0; i < 10; i++) 
		try {
			solo.clearEditText(1);
			solo.enterText(1, LoginPWD);
			break;
		} catch (Exception e) {
			System.out.println(e);
			solo.sleep(1000);
		}
	}

	public String get_密码() {
		for (int i = 0; i < 5; i++)
			try {
				return solo.getEditText(1).getText().toString();
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(500);
			}
		return "出错...";
	}

	public void click_记住密码() throws Exception {
		if (!solo.isCheckBoxChecked(0)) {
			for (int i = 0; i < 10; i++) 
				try {
					solo.clickOnCheckBox(0);
					break;
				} catch (Exception e) {
					System.out.println(e);
					solo.sleep(1000);
				}
		}
	}

	public Boolean get_记住密码() {
		return solo.isCheckBoxChecked(0);
	}

	public void click_重置() throws Exception {
		for (int i = 0; i < 5; i++)
			try {
				solo.clickOnButton("重置");
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(500);
			}
	}

	public void click_高级设置() throws Exception {
		for (int i = 0; i < 5; i++)
			try {
				solo.clickOnButton("高级设置");
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(500);
			}
	}

	public void click_登录() throws Exception {
		for (int i = 0; i < 10; i++) 
			try {
				
				solo.clickOnButton("登录");
				break;
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(1000);
			}
		waittingDeskTop();
	}

	public String get_提示信息() throws Exception {
		for (int i = 0; i < 5; i++)
			try {
				return solo.getText(0).getText().toString();
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(500);
			}
		return "出错...";
	}
}
