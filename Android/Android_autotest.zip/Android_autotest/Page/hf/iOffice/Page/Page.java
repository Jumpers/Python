package hf.iOffice.Page;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import com.jayway.android.robotium.solo.Solo;

public class Page{
	protected Solo solo;
	protected BitmapShotActivity bitmapShotActivity=new BitmapShotActivity();
	public String page;
	protected String testcase;

	public Page(Solo solo) throws InterruptedException {
		solo.sleep(1000);
		this.solo=solo;
	}
	public void waittingDeskTop() throws Exception {
		solo.sleep(1000);
		for (int i = 0; i < 10; i++) {
			if (solo.searchText("关于 iOffice"))
				break;
			else {
				solo.sleep(500);
			}
		}
	}
	
	public void waittingMode(String mode) throws Exception {
		solo.sleep(1000);
		for (int i = 0; i < 10; i++) {
			if (solo.searchText(mode))
				break;
			else {
				solo.sleep(1000);
			}
		}
	}
	
	public void click_注销() throws Exception {
		for (int i = 0; i < 10; i++) {
			if(solo.getText(0).getText().toString().equals("iOffice")&&solo.getText(1).getText().toString().equals("移动办公系统"))
				break;
			solo.goBack();
			if (solo.searchButton("注销")) {
				for (int a = 0; a < 10; a++) 
					try {
						solo.clickOnButton("注销");
						solo.sleep(2000);
						break;
					} catch (Exception e) {
						System.out.println(e);
						solo.sleep(1000);
					}
				break;
			}
		}
	}
	
	public String getCurrentDate(){
		SimpleDateFormat simpleDateTimeFormat =    new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
		return simpleDateTimeFormat.format(Calendar.getInstance().getTime());	
	}
	
	public String getCurrentDate(String format){
		SimpleDateFormat simpleDateTimeFormat =    new SimpleDateFormat(format );
		return simpleDateTimeFormat.format(Calendar.getInstance().getTime());	
	}
	
	public void getDown() throws InterruptedException{
		solo.sendKey(20);
	}
	
	public void goBack() throws Exception{
		solo.sleep(1000);
		solo.goBack();
		solo.sleep(500);
	}
	
	public boolean scrollDown(){
		boolean scrollDown=solo.scrollDown();
		solo.sleep(1000);
		return scrollDown;
	}
	
	public boolean scrollUp(){
		return solo.scrollUp();
	}
	
	public String get_提示信息() throws Exception {
		for (int i = 0; i < 5; i++)
			try {
				return solo.getText(0).getText().toString();
			} catch (Exception e) {
				System.out.println(e);
				solo.sleep(500);
			}
		return "出错...";
	}
	
	public void scollUpTo(String name){
		while(scrollUp()){
		}
		while(true){
			if(solo.searchText(name))
				break;
			if(!scrollDown())
				break;
		}
	}
	
	public void scollDownTo(String name){
		while(true){
			if(solo.searchText(name))
				break;
			if(!scrollDown())
				break;
		}
	}
}
