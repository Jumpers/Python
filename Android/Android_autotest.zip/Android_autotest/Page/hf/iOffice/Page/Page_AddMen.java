package hf.iOffice.Page;
import com.jayway.android.robotium.solo.Solo;


public class Page_AddMen extends Page{
	public Page_AddMen(Solo solo,String testcase) throws InterruptedException {
		super(solo);
		this.testcase=testcase;
		this.page="Page_AddMen";
	}

	public Page_AddMen(Solo solo) throws InterruptedException {
		super(solo);
	}
	
	public void select_人员(String empName) throws Exception{
		solo.clickOnText(empName);
	}
	
	public void click_完成(String mode) throws Exception{
		solo.clickOnText("完成");
		waittingMode(mode);
		solo.sleep(1000);
	}
}
