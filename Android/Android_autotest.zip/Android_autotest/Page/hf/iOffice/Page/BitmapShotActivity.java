package hf.iOffice.Page;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Environment;
import android.view.View;

public class BitmapShotActivity {

	public static String baseDIR = Environment.getExternalStorageDirectory()
			.getAbsolutePath();
	public static String subDIR = "/test/"+getCurrentDate("yyyyMMdd");
	public static String SCREEN_SHOTS_LOCATION = baseDIR + subDIR;

	/*
	 * public static void takeScreenShot(View view) throws Exception {
	 * takeScreenShot(view, "default"); }
	 */
	public static void takeScreenShot(View view, String testcase, String page) throws Exception {

//		String dir=SCREEN_SHOTS_LOCATION+"/"+testcase;
//		System.out.println("系统路径：" + dir);// 获取系统的SD卡路径
//
//		view.setDrawingCacheEnabled(true);
//		view.setDrawingCacheBackgroundColor(Color.WHITE);
//		view.buildDrawingCache();
//		Bitmap b = view.getDrawingCache();
//		FileOutputStream fos = null;
//		try {
//			File sddir = new File(dir);
//			if (!sddir.exists()) {
//				sddir.mkdirs();
//			}
//
//			fos = new FileOutputStream(dir+"/"+getCurrentDate("HHmmss")+page+ ".jpg");
//			System.out.println("保存图片的路径：" + dir+"/"+ getCurrentDate("HHmmss") +page
//					+ ".jpg");
//			if (fos != null) {
//				b.compress(Bitmap.CompressFormat.JPEG, 90, fos);
//				fos.close();
//			}
//		} catch (Exception e) {
//		}
	}
	public static String getCurrentDate(String format){
		SimpleDateFormat simpleDateTimeFormat =    new SimpleDateFormat(format);
		return simpleDateTimeFormat.format(Calendar.getInstance().getTime());	
	}
}