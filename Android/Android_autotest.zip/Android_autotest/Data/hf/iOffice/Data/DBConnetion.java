
package hf.iOffice.Data;
/*
 *简单的与数据库连接的程序
 */
import java.sql.*;
import java.util.ArrayList;
import android.test.ActivityTestCase;
public class DBConnetion extends ActivityTestCase{
    /**
     *此主方法中演示了与数据库建立连接并实现相关操作的步骤：
     *1、forName方法加载数据库驱动程序；
     *2、DriverManager的getConnection方法与数据库建立连接，并返回Connection接口的子类对象赋给conn；
     *3、conn对象调用createStatement方法，返回Statement的对象赋给stmt,
     *   通过此对象调用相应的方法实现对数据库的查询、修改等操作；
     *4、用ResuitSet的对象作为容器存放从数据库读取的记录并print将记录最终输出。
     * @throws SQLException 
     */
	protected Connection conn = null;
    protected Statement st=null;
    protected ResultSet rs= null;
	public DBConnetion() throws SQLException{
		st=getConnection();
	}


	protected Statement getConnection() throws SQLException {
		for (int i = 0; i < 10; i++)
			try {
				String sql2008url = "jdbc:microsoft:sqlserver://10.100.2.94:1433;DatabaseName=iOffice_fuli";
				String sql2008Driver = "com.microsoft.jdbc.sqlserver.SQLServerDriver";
				String sql2008user = "sa";
				String sql2008pass = "hongFAN!@#";

				Class.forName(sql2008Driver);
				conn = DriverManager.getConnection(sql2008url, sql2008user,sql2008pass);
				break;
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
				try {
					wait(1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				try {
					wait(1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			}
		System.out.println("Success!");
		st = conn.createStatement();
		return st;
	}

	protected String getSingleWordString(String SQL) throws SQLException {
		String result = "";
		try {
			rs = st.executeQuery(SQL);
		} catch (Exception e) {
			System.out.println(SQL);
		}
		rs.next();
		try {
			result = rs.getString(1);
		} catch (SQLException e) {
		}
		return result;
	}
	
	protected int getSingleWordInt(String SQL) throws SQLException {
		int result = 0;
		try {
			rs = st.executeQuery(SQL);
		} catch (Exception e) {
			System.out.println(SQL);
		}
		rs.next();
		try {
			result = rs.getInt(1);
		} catch (SQLException e) {
		}
		return result;
	}
	
	protected String[] getSingleLine(String SQL) throws SQLException {
		String[] result = { "", "", "", "", "", "", "", "", "","","" };
		try {
			rs = st.executeQuery(SQL);
		} catch (Exception e) {
			System.out.println(SQL);
		}
		rs.next();
		for (int i = 1;; i++) {
			try {
				result[i-1] = rs.getString(i);
			} catch (SQLException e) {
				break;
			}
		}
		return result;
	}
	
	protected ArrayList<String> getLines(String SQL) throws SQLException {		
		ArrayList<String> result = new ArrayList<String>();
		try {
			rs = st.executeQuery(SQL);
		} catch (Exception e) {
			System.out.println(SQL);
		}
		int j=1;
		while (rs.next()) {
			for (int i = 0;; i++) {
				try {
					result.add(rs.getString(i + 1));
				} catch (SQLException e) {
					result.add("行数"+(j));
					break;
				}
			}
			j++;
		}
		return result;
	}
	
	protected ArrayList<String> getLines(String SQL,int line) throws SQLException {		
		ArrayList<String> result = new ArrayList<String>();
		try {
			rs = st.executeQuery(SQL);
		} catch (Exception e) {
			System.out.println(SQL);
		}
		
		int j=1;
		while (rs.next()&&j<=line) {
			for (int i = 0;; i++) {
				try {
						result.add(rs.getString(i + 1));
				} catch (SQLException e) {
					result.add("行数"+(j));
					break;
				}
			}
			j++;
		}
		return result;
	}
	
	protected void closeConnection() throws SQLException
	{
	       if(rs != null) {
	            rs.close();
	            rs = null;
	        }
	        if(st != null) {
	        	st.close();
	        	st = null;
	        }
	        if(conn != null) {
	            conn.close();
	            conn = null;
	        }
	}

}