package hf.iOffice.Data.ShowMessage.SendMessage;

import hf.iOffice.Data.Data_BaseInformation;
import hf.iOffice.Data.Data_connect;
import hf.iOffice.ShowMessage.SendMessage.SQL_SendMessage_Begin;

import java.sql.SQLException;
import java.util.ArrayList;

public class Data_SendMessage_Begin  extends Data_BaseInformation{
	
	private String[] value_登录人;
	private ArrayList<String> value_预期传阅信息;
	private ArrayList<String> value_预期讨论信息;
	private String value_是否密送;
	private ArrayList<String>  value_传阅人员;
	private String[] value_菜单列表={"","","","","","",""};
	private int value_总记录数;
	private Data_connect data_connect;
	public SQL_SendMessage_Begin  sql_SendMessage_Begin =new SQL_SendMessage_Begin ();
	public Data_SendMessage_Begin() throws SQLException{
		data_connect= new Data_connect();
		value_登录人=data_connect.get_singleLine(sql_SendMessage_Begin.getLoginID());
		value_预期传阅信息=data_connect.get_Lines(sql_SendMessage_Begin.getMessageInf(value_登录人[1]),10);
		value_总记录数=data_connect.get_singleWordInt(sql_SendMessage_Begin.getMessCount(value_登录人[1]));
	}

	public String[] getValue_菜单列表() {
		return value_菜单列表;
	}
	
	public void setValue_预期传阅人员信息(int i) throws SQLException {
		value_是否密送=data_connect.get_singleWordString(sql_SendMessage_Begin.getSecret(value_预期传阅信息.get(i*9+7),value_登录人[1]));
		value_传阅人员=data_connect.get_Lines(sql_SendMessage_Begin.getReceiverInf(value_预期传阅信息.get(i*9+7),value_是否密送,value_登录人[1]), 10);
	}
	
	public void setValue_预期讨论信息(int i) throws SQLException {
		value_预期讨论信息=data_connect.get_Lines(sql_SendMessage_Begin.getDiscussInf(value_预期传阅信息.get(i*9+7)), 10);
	}
	
	public void setValue_菜单列表(int i) throws SQLException {
		value_菜单列表=data_connect.get_singleLine(sql_SendMessage_Begin.getMsgStatus(value_预期传阅信息.get(i*9+7), value_登录人[1]));
	}
	
	
	
	public int getValue_总记录数() {
		return value_总记录数;
	}
	
	
	public String[] getValue_登录人() {
		return value_登录人;
	}
	
	public  ArrayList<String> getValue_预期传阅人员信息() {
		return value_传阅人员;
	}
	
	public  ArrayList<String> getValue_预期传阅信息() {
		return value_预期传阅信息;
	}
	
	public  ArrayList<String> getValue_预期讨论信息() {
		return value_预期讨论信息;
	}
	
	public int getValue_讨论总数(int i) throws SQLException {
		return data_connect.get_singleWordInt(sql_SendMessage_Begin.getDiscussCount(value_预期传阅信息.get(i*9+7)));
	}
	
	public int getValue_传阅人员总数(int i) throws SQLException {
		return data_connect.get_singleWordInt(sql_SendMessage_Begin.getReceiverCount(value_预期传阅信息.get(i*9+7)));
	}
	
	public String getValue_记录错误信息(int i) {
		return "出错帐号:"+value_登录人[0]+";一共"+value_总记录数+"条记录,其中第"+i+"条记录;"+"标题:"+value_预期传阅信息.get(i*9);
	}	
	public String getValue_菜单错误信息(int subjectnum,int menunum) {
		return "出错帐号:"+value_登录人[0]+";一共"+value_总记录数+"条记录,其中第"+subjectnum+"条记录;"+"标题:"+value_预期传阅信息.get(subjectnum*9)+",Status:"+value_菜单列表[menunum];
	}
	public String getValue_菜单错误信息(int subjectnum,int menunum1,int menunum2) {
		return "出错帐号:"+value_登录人[0]+";一共"+value_总记录数+"条记录,其中第"+subjectnum+"条记录;"+"标题:"+value_预期传阅信息.get(subjectnum*9)+",Status:"+value_菜单列表[menunum1]+","+value_菜单列表[menunum2];
	}
	public String getValue_讨论错误信息(int subjectnum,int discussnumm) {
		return "出错帐号:"+value_登录人[0]+";一共"+value_总记录数+"条记录,其中第"+subjectnum+"条记录;"+"标题:"+value_预期传阅信息.get(subjectnum*9)+",讨论信息:"+value_预期讨论信息.get(discussnumm * 4+2);
	}
	
	public String getValue_传阅人员错误信息(int subjectnum,int receivernumm) {
		return "出错帐号:"+value_登录人[0]+";一共"+value_总记录数+"条记录,其中第"+subjectnum+"条记录;"+"标题:"+value_预期传阅信息.get(subjectnum*9)+",接收人员:"+value_传阅人员.get(receivernumm * 8+1)+";确认信息:"+value_传阅人员.get(receivernumm * 8+2)+","+value_传阅人员.get(receivernumm * 8+3);
	}
}
