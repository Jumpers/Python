package hf.iOffice.Data.ShowMessage.Operation;

import java.sql.SQLException;

import hf.iOffice.Data.Data_BaseInformation;
import hf.iOffice.Data.Data_connect;
import hf.iOffice.ShowMessage.Operation.SQL_ShowMessage_Discuss;

public class Data_ShowMessage_Discuss extends Data_BaseInformation{
	private String[] value_登录人;
	private String value_讨论内容;
	private String value_发表讨论时间;
	private String[] value_MsgSerInf;
	private Data_connect data_connect;
	public SQL_ShowMessage_Discuss   sql_ShowMessage_Discuss  =new SQL_ShowMessage_Discuss  ();
	public Data_ShowMessage_Discuss() throws SQLException{
		data_connect=new Data_connect();
		value_讨论内容="自动化测试讨论内容"+getAutoTestNum();
		value_登录人=data_connect.get_singleLine(sql_ShowMessage_Discuss.getLoginID());
		value_MsgSerInf=data_connect.get_singleLine(sql_ShowMessage_Discuss.getMessageInf2(value_登录人[1]));
	}
	public String get_讨论内容(){
		return value_讨论内容;
	}
	
	public String[] getValue_登录人() {
		return value_登录人;
	}
	
	public void set_发表讨论时间(String value_发表讨论时间) {
		this.value_发表讨论时间=value_发表讨论时间;
	}
	
	public String get_发表讨论时间() {
		return value_发表讨论时间.substring(0,16);
	}
	
	public String[] get_MsgSerInf() {
		return value_MsgSerInf;
	}
	
	public String getValue_记录错误信息() {
		return "出错帐号:"+value_登录人[0]+"标题:"+value_MsgSerInf[0];
	}
	
	public int assert_数据库验证() throws SQLException{
		return data_connect.get_singleWordInt(sql_ShowMessage_Discuss.getNewDiscuss(value_MsgSerInf[1],value_登录人[1],value_讨论内容));
	}
}
