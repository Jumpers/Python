package hf.iOffice.Data;

import java.text.SimpleDateFormat;
import java.util.Calendar;
public class Data_BaseInformation {
	public  String  loginId1="test";
	public  String  loginIdPwd1="123456";
	public  String  loginId2="liuminshan";
	public  String  loginIdPwd2="123456";
	public  String  loginId3="chenli";
	public  String  loginIdPwd3="654321";
	public  String  loginIdOther="ceo";
	public  String  loginIdPwdOther="123456";
//	public  String  loginId1="ceo";
//	public  String  loginIdPwd1="123456";
//	public  String  loginId2="ffx";
//	public  String  loginIdPwd2="123456";
//	public  String  loginIdOther="test";
//	public  String  loginIdPwdOther="123456";
	public  String  loginIP1="10.100.2.94:8007";
	//public  String  loginIP2="10.100.2.50:3001";
	public  String  loginIP2="10.100.2.64:3009";
	public  String  loginIP="";
	
	public String getCurrentDate(){
		SimpleDateFormat simpleDateTimeFormat =    new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
		return simpleDateTimeFormat.format(Calendar.getInstance().getTime());
	}
	
	public String getAutoTestNum(){
		SimpleDateFormat simpleDateTimeFormat =    new SimpleDateFormat( "yyyyMMddHHmmss" );
		return simpleDateTimeFormat.format(Calendar.getInstance().getTime());
	}
}
