package hf.iOffice.Data;



import java.sql.SQLException;
import java.util.ArrayList;

public class Data_connect extends DBConnetion{

	public Data_connect() throws SQLException {
		super();
	}
	
	public String get_singleWordString(String SQL) throws SQLException{
		return getSingleWordString(SQL);
	}
	
	public int get_singleWordInt(String SQL) throws SQLException{
		return getSingleWordInt(SQL);
	}
	
	public String[] get_singleLine(String SQL) throws SQLException{
		return getSingleLine(SQL);
	}
	
	public ArrayList<String> get_Lines(String SQL) throws SQLException{
		return getLines(SQL);
	}
	
	public ArrayList<String> get_Lines(String SQL,int line) throws SQLException{
		return getLines(SQL,line);
	}
}
