/** Automatically generated file. DO NOT MODIFY */
package hf.iOffice.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}