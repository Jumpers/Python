package hf.iOffice.ShowMessage.SendMessage;

import hf.iOffice.ShowMessage.SQL_ShowMessage_Base;

public class SQL_SendMessage_Begin  extends SQL_ShowMessage_Base{

	public String getLoginID(){
		return "select top 1 LoginID,empid from mrBaseInf " +
				"where LoginID<>'chenli' " +
				"and AllowLogin=1 " +
				"and Status=1 " +
				"and loginid='xuwanfeng' " +
				"and empid in(select empid from ifShowMsg " +
									"where (Status=0 or Status=-1)) "+
				"order by NEWID()";
	}
	
	public String getMessageInf(String loginInf){
		return "select top 10  Subject,CDate,EMPNAME,Status,Content,cast(year(CDate) as varchar(4))+'年'+cast(MONTH(CDate) as varchar(4))+'月'+cast(DAY(CDate) as varchar(4))+'日'+' '+cast(DATEPART(hh,CDate) as varchar(4))+substring(CONVERT(varchar(30),CDate,8),3,3) DetailCDate,isnull(FromDepName,'') FromDepName,MsgSerID "
				+ "from(       "
				+ "SELECT s.Subject Subject,s.CDate CDate,s.EMPNAME EMPNAME,s.FromDepName FromDepName,s.content content,s.MsgSerID MsgSerID,s.Status Status "
				+ "FROM ifShowMsg s "
				+ "where empid='"
				+ loginInf
				+ "' "
				+ "and (Status=0 or Status=-1) " + ") a order by CDate desc";
	}
	
	public String getMessCount(String loginInf) {
		return "select count(1) from ifShowMsg "+
				"where empid='"+loginInf+"' " +
				"and (Status=0 or Status=-1) ";
	}
}
