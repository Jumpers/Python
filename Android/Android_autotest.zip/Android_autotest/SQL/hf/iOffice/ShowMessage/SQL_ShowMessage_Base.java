package hf.iOffice.ShowMessage;

public class SQL_ShowMessage_Base {
	public String getMsgStatus(String MsgSerID,String empid){
		return 	"declare @empid int; "+
				"declare @MsgSerID int; "+
				"set @empid="+empid+"; "+
				"set @MsgSerID="+MsgSerID+"; "+
				"select  "+
				"(select COUNT(1) from ifShowMsg where EmpID=@empid and MsgSerID=@MsgSerID) '我发送的',"+
				"(select COUNT(1)  from ifShowMsg where EmpID=@empid and MsgSerID=@MsgSerID and Status=-1) '保存退出',"+
				"(select COUNT(1)  from ifShowMsg where MsgSerID=@MsgSerID and Status<>2 and (readd=1 or EmpID=@empid) and (bsecret<>1 or bsecret is null)) '新增人员',"+
				"(select COUNT(1)  from ifShowMsgLabel where EmpID=@empid and MsgSerID=@MsgSerID and LabeledFlag=0 and MsgSerID in (select MsgSerID from ifShowMsg where status<>-1 and status<>2)) '已确认',"+
				"(select COUNT(1)  from ifShowMsgLabel where EmpID=@empid and MsgSerID=@MsgSerID and LabeledFlag=1) '未确认',"+
				"(select COUNT(1) from ifShowMsg where MsgSerID=@MsgSerID and status<>-1 and status<>2 and (bsecret<>1 or bsecret is null)) '发表讨论',"+
				"(select COUNT(1) from ifShowMsgLabel where MsgSerID=@MsgSerID and LabeledFlag=0) '是否已确认'";
	}
	
	public String getFileCount(String MsgSerID){
		return 	"select count(1) " +
				"from ioFileAtt " +
				"where Mode='ifShowMsg' " +
				"and ModeID='"+MsgSerID+"' ";
	}
	
	public String getFileInf(String MsgSerID){
		return 	"select FileName,FileSize " +
				"from ioFileAtt " +
				"where Mode='ifShowMsg' " +
				"and ModeID='"+MsgSerID+"' "+
				"order by cdate desc";
	}

	
	public String getReceiverInf(String MsgSerID,String bsecret,String empid){
		String SQLLeft= 	"select  top 10 empid=ba.empid, "+
				 "name=ba.name , "+
				 "status=case when labeledflag=0 then case when agentnote is null then '' else '{'+agentnote+'} ' end+ '已确认'+'  '+isnull(convert(varchar(16),LabelDate,120),'') when unsealflag=1 then case when agentnote is null then '' else '{'+agentnote+'} ' end+ '未开封' else case when agentnote is null then '' else '{'+agentnote+'} ' end+ '已开封'+'  '+isnull(convert(varchar(16),LabelDate,120),'') end+   case when labelnote is null then '' else ' {'+labelnote+'}' end , "+
				 "note=replace(cast(l.note as varchar(5000)),char(13),'<br>') , "+
				 "sortfield=case when b.sortid is null or len(b.sortid)=0 then 999 else b.sortid end  , "+
				 "sortfield1=case when len(ba.SortWeighted)=0 or ba.SortWeighted is null then '999' else ba.sortweighted end , "+
				 "ba.SortID  "+
				 "from  mrbaseinf ba WITH(NOLOCK)  "+
				 "join mrposition po WITH(NOLOCK)  "+
				 "	on ba.empid=po.empid   "+
				 "join mrdep dep WITH(NOLOCK)  "+
				 "	on dep.depid=po.depid   "+
				 "join mrbranch br WITH(NOLOCK)  "+
				 "	on br.branchid=dep.branchid   "+
				 "left join mrEmpPosition b WITH(NOLOCK)  "+
				 "	on po.PositionID=b.PositionID   "+
				 "join ifShowMsgLabel l WITH (NOLOCK)  "+
				 "	on l.empid=ba.empid   "+
				 "where 1=1   "+
				 "	and l.msgserid=  "+MsgSerID;
		
		String SQLRight	=	 "	and po.sortid=1   "+
				 "order by br.sortcode,dep.sortcode,sortfield,sortfield1,ba.SortID ";
		if(bsecret.equals("1"))
			return SQLLeft+" and l.empid="+empid+SQLRight;
		else {
			return SQLLeft+SQLRight;
		}
	}
	
	public String getSecret(String MsgSerID,String empid){
		return "select case when empid="+empid+" then 0 else bsecret end from ifShowMsg where MsgSerID="+MsgSerID;
	}
	
	
	public String getReceiverCount(String MsgSerID){
		return 	"select count(1) from ifShowMsgLabel d "+
				"where d.msgserid= "+MsgSerID;
	}
	
	public String getDiscussCount(String MsgSerID){
		return 	"select count(1) from ifShowMsgDiscuss d "+
				"where d.msgserid= "+MsgSerID;
	}
	
	public String getDiscussInf(String MsgSerID){
		return 	"select top 10 m.Name,CONVERT(varchar(30),d.CDate ,20),d.Content from ifShowMsgDiscuss d,mrBaseInf m "+
				"where  d.CEmpID=m.EmpID "+
				"and d.msgserid= "+MsgSerID+" "+
				"order by CDate desc";
	}
}
