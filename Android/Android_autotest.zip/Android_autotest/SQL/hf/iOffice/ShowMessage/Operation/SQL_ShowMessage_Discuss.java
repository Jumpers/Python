package hf.iOffice.ShowMessage.Operation;

public class SQL_ShowMessage_Discuss {
	public String getLoginID(){
		return "select top 1 LoginID,empid,name from mrBaseInf " +
				"where LoginID<>'chenli' " +
				"and AllowLogin=1 " +
				"and Status=1 " +
				"and (empid in(select sl.empid from ifShowMsgLabel sl,ifShowMsg s " +
									"where S.MsgSerID=SL.MsgSerID  and s.Status<>-1 and s.status<>2 and s.MsgSerID<>129884 and (s.bsecret<>1 or s.bsecret is null) )" +
				"or empid in (select empid from ifShowMsg where Status<>-1 and status<>2 and MsgSerID<>129884  and (bsecret<>1 or bsecret is null)))"+
				"order by NEWID()";
	}
	public String getMessageInf2(String loginInf){
		return 	"select Subject,MsgSerID  "+
				"from(                                                                                                                                                                                                                                       "+
				"		select top 1 s.Subject Subject,s.CDate CDate,s.EMPNAME EMPNAME,s.FromDepName FromDepName, s.Content  Content,s.MsgSerID MsgSerID                                                                                                                                                   "+
				"		FROM ifShowMsgLabel SL,ifShowMsg S                                                                                                                                                                                                   "+
				"		WHERE S.MsgSerID=SL.MsgSerID                                                                                                                                                                                                         "+
				"		AND SL.EmpID='"+loginInf+"'      " +
				" 		and s.Status<>-1 "+               
				"      	and s.MsgSerID<>129884 and (s.bsecret<>1 or s.bsecret is null)"+
				"		order by newid()) a ";
	}
	
	public String getNewDiscuss(String MsgSerID,String Empid,String Content){
		return 	"select COUNT(1) from ifShowMsgDiscuss " +
				" where MsgserID='"+MsgSerID+"' " +
				" and CEmpID='"+Empid+"' " +
				" and Content like '"+Content+"'";
	}
}
